#Yashar Hashemi <yh7900@bard.edu>
#2/22/16
#
#Assignment 1 -- Sing and Dance
#I revieced help from the text book Learning Computing with Robots by Deepak Kumar
from Myro import *



def frequencyToPitch(f): 
    return 69+12*log((f/440),2)
    
def pitchToFreq(p):
    return 440*2**((p-69)/12)
    
    
def playMajorScale(p):
    beep(.5, pitchToFreq(p))
    beep(.5, pitchToFreq(p+2))
    beep(.5, pitchToFreq(p+4))
    beep(.5, pitchToFreq(p+5))
    beep(.5, pitchToFreq(p+7))
    beep(.5, pitchToFreq(p+9))
    beep(.5, pitchToFreq(p+11))
    beep(.5, pitchToFreq(p+12))

    



#the lines above allow me to find the correct input in pitch number that corresponds to a value in Hertz
#this is useful because it allows the user to input a pitch number and get a Hertz value that corresponds to a piano key where middle C is the 40th key or pitch
  
def dance(): 
    if yesno('do you want me to perform?')==True:
    #here I ask if the user wants the robot to perform. 
    #If they say yes, the program will perform all of the following indented functions
    #if they say no, the program will skip to the 'else' function which has the same indentation ad the 'if' function    
        top= float(ask('how long do you want the robots performance to be?'))
        #variable "top" stands for "time of performance" I use the ask function to get a number inputted from the user and I turn it into a float number that defines the length of the performance
        sor= float(ask("how fast do you want the robot to move?(pick a number between 0 and 1)"))
        #variable "sor" stands for "speed of robot", I again use the ask function and the float function but instead of determining the lenght of the performance, I use it to determine the power of the motors
        p=int(ask('what pitch number do you want your performance to start at?(for best results, choose a number between 60 and 90)'))
        #variable "p" stands for "pitch". I am asking the user to input the pitch(or piano key) they want the song to start with
        nop= int(ask('how many times do you want to robot to perform?')) 
        #variable "nop"
        for i in range (nop):            
            motors(sor, sor)
            #here I use the variable 'sor' to determine the speed of the left and right motors that control the robot's wheels
            beep(top/10, pitchToFreq(p))
            #since there are 10 steps in this performance, I divide "top" by 10 so that when all of the steps of the performance are completed, the total time will equal the user inputed time of the performance
            motors(-sor, -sor)
            beep(top/10, pitchToFreq(p+7))
            #I add 7 onto 'p' because I want to song to be in a major scale
            #major scales start with a key and proceed according to the progression +2, +2, +1, +2, +2, +2, +1... (or 0,2,4,5,7,9,11.12...) 
            #all of the following pitches are in the major scale of the starting pitch
            motors(-sor, 0)
            beep(top/10, pitchToFreq(p+4))
            motors(sor, 0)
            beep(top/10, pitchToFreq(p+11))
            motors(sor, 0)
            beep(top/10, pitchToFreq(p+14))
            motors (-sor, 0) 
            beep(top/10, pitchToFreq(p +11))
            motors (sor, -sor)
            beep(top/10, pitchToFreq(p +7))
            motors (-sor, sor)
            beep(top/10, pitchToFreq(p+4))
            motors (-sor, .2)
            beep(top/10, pitchToFreq(p))
            stop()        
    else:
        print('Goodbye')                
    
   
            
            
    