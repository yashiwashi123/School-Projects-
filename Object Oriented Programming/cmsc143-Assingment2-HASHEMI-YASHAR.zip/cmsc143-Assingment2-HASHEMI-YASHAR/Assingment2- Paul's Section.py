from Myro import *

if ask('Hit Enter on all computers at the same time when you are ready to go!') == (""): 
    
    speak("Once upon a time, there was a boy robot named Tim and a girl robot named Tam, who had never met.")
    wait(1)
    speak("For a while, even thouh they lived nearby each other, they never noticed each other.")
    wait(2)
   
    speak("Until one day Tim's get, eye, are, red 0 and he finally noticed the girl robot.")
    

   