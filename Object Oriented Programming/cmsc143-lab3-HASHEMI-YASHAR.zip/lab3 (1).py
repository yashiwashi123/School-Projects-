#Yashar Hashemi
#2/19/2016
#cmsc143
#Lab 3
#I recieved help  on this project from Elias Posen and Khondakr Salehin
from Myro import *
 
from math import *


         
  

def frequencyToPitch(f): 
    return 69+12*log((f/440),2)
    
def pitchToFreq(p):
    return 440*2**((p-69)/12)
    
def playMajorScale(p):
    beep(.5, pitchToFreq(p))
    beep(.5, pitchToFreq(p+2))
    beep(.5, pitchToFreq(p+4))
    beep(.5, pitchToFreq(p+5))
    beep(.5, pitchToFreq(p+7))
    beep(.5, pitchToFreq(p+9))
    beep(.5, pitchToFreq(p+11))
    beep(.5, pitchToFreq(p+12))    
'''
while True:
    status= getGamepad()
    print ("The entire status of the gamepad looks like", status)
    buttons = status["button"]
    print ("The buttons:", buttons)
    print ("The first button reads", buttons[0])
    
    axes = status["axis"]
'''

def myGamepad():
    '''
    HOW TO USE MY GAMEPAD
    button 1: stops the gamepad
    button 2: uses the light sensors to get light and prints the values
    button 3: the scribbler bot takes a picture
    button 4: prints "How are you today?"
    button 5: plays the A Major scale 
    button 6: uses text to speech to say "What did you do today?"
    button 7: prints "this is cool!"
    button 8: prints "I like juice"
    up button: robot moves forwards
    down button: robot moves backwards
    left button: robot spins counter clockwise
    right button: robot spins clockwise
    '''
    keepGoing = True

       
    while keepGoing:
        status = getGamepad()
        buttons = status['button']
        axes = status['axis']
        
        if buttons[0]==1:
            keepGoing= False
            
        if buttons[1]==1:
            print(getLight())
        
        if buttons[2]==1:
            p=takePicture()
            show(p)            
        if buttons[3]==1:
            print ("How are you today?")
        if buttons[4]==1:
            playMajorScale (69)
        if buttons[5]==1:
            speak("What did you do today?")
        if buttons[8]==1:
            print("this is cool!")
        if buttons[9]==1:
            print ("I like juice")
        if axes[1]==1.0:
            motors(-1,-1)
        #when the buttons are not pressed, the value of both the x and y axis buttons = -.01, not 0
        if axes[1]== -0.01:
            motors(0,0) 
        if axes[1]== -1.0:
            motors(1,1)
        if axes[0]==1.0:
            motors (1,-1)
        if axes [0]==-.01:
            motors (0,0)
        if axes [0]==-1.0:
            motors (-1,1)      
            